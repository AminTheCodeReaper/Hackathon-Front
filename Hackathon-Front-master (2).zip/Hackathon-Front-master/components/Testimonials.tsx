"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";

const testimonials = [
  { name: "سارا احمدی", role: "مدیر بازاریابی، دیجی‌شاپ", avatar: "س", color: "from-pink-500 to-rose-500", text: "هوشمند تولید محتوای ما رو به کلی متحول کرد. الان در یک ساعت کاری که قبلاً یک هفته طول می‌کشید رو انجام می‌دیم.", rating: 5 },
  { name: "محمد رضایی", role: "بنیان‌گذار، استارتاپ فین‌تک", avatar: "م", color: "from-blue-500 to-indigo-500", text: "پشتیبانی مشتری ما ۲۴/۷ شد بدون اینکه هزینه‌مون بره بالا. رضایت مشتری از ۷۰٪ به ۹۵٪ رسید!", rating: 5 },
  { name: "نازنین کریمی", role: "مدیر محصول، اپ سلامت", avatar: "ن", color: "from-emerald-500 to-teal-500", text: "API مستقیم و SDK فارسی‌شون خیلی خوب بود. در کمتر از یه روز تونستیم یکپارچه‌سازی کنیم.", rating: 5 },
  { name: "علی حسینی", role: "مدیرعامل، آموزشگاه آنلاین", avatar: "ع", color: "from-amber-500 to-orange-500", text: "بهترین سرمایه‌گذاری‌ای بود که کردیم. ROI ما در ماه اول مثبت شد و الان ۵ برابر شده.", rating: 5 },
  { name: "مریم شیرازی", role: "مدیر فروش، شرکت B2B", avatar: "م", color: "from-violet-500 to-purple-500", text: "ربات فروش هوشمند اونقدر خوب صحبت می‌کنه که مشتریامون فکر می‌کنن با آدم طرفن.", rating: 5 },
  { name: "رضا تهرانی", role: "CTO، پلتفرم لجستیک", avatar: "ر", color: "from-cyan-500 to-blue-500", text: "امنیت داده برامون خیلی مهمه. اینکه سرورها داخل ایرانه و داده‌ها اینجا می‌مونه خیالمو راحت کرد.", rating: 5 },
];

export default function Testimonials() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  return (
    <section className="py-24 bg-[#080818] relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-violet-500 to-transparent" />
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-14"
        >
          <p className="text-pink-400 text-xs font-bold mb-2 tracking-widest">— نظرات مشتریان —</p>
          <h2 className="text-4xl md:text-5xl font-black text-white">آن‌ها به هوشمند اعتماد کردند</h2>
          <p className="text-white/50 text-base mt-3">بیش از ۲۰۰۰ کسب‌وکار ایرانی هر روز از هوشمند استفاده می‌کنند.</p>
        </motion.div>

        <div ref={ref} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: i * 0.08, duration: 0.4 }}
              whileHover={{ y: -6, scale: 1.02 }}
              className="group bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 hover:border-violet-500/40 transition-all duration-300"
            >
              <div className="flex gap-0.5 mb-4">
                {[...Array(t.rating)].map((_, j) => (
                  <span key={j} className="text-amber-400 text-lg">★</span>
                ))}
              </div>
              <p className="text-white/70 text-sm leading-relaxed mb-6 line-clamp-3">"{t.text}"</p>
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-full bg-gradient-to-br ${t.color} flex items-center justify-center text-white font-bold text-base shadow-lg`}>
                  {t.avatar}
                </div>
                <div>
                  <div className="text-white font-semibold text-sm">{t.name}</div>
                  <div className="text-white/40 text-xs">{t.role}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}