"use client";

import { motion } from "framer-motion";

export default function Hero() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.2, delayChildren: 0.1 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-24">
      {/* پس‌زمینه پویا */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-20 left-10 w-96 h-96 bg-violet-600 rounded-full blur-[150px] opacity-30 animate-pulse" />
        <div className="absolute bottom-20 right-10 w-80 h-80 bg-cyan-600 rounded-full blur-[120px] opacity-30 animate-pulse delay-1000" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-indigo-500/20 rounded-full blur-[100px]" />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center gap-2 bg-violet-500/20 border border-violet-500/40 text-violet-300 text-sm px-4 py-1.5 rounded-full mb-6 backdrop-blur-sm"
        >
          <span className="w-2 h-2 rounded-full bg-violet-400 animate-pulse" />
          نسل جدید هوش مصنوعی فارسی
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="text-5xl md:text-7xl lg:text-8xl font-black leading-tight mb-6"
        >
          کسب‌وکارت رو با{" "}
          <span className="bg-gradient-to-r from-violet-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent glow-text">
            هوش مصنوعی
          </span>{" "}
          متحول کن
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="text-base md:text-lg text-white/60 max-w-xl mx-auto mb-8 leading-relaxed"
        >
          هوشمند اولین پلتفرم هوش مصنوعی بومی‌سازی‌شده برای کسب‌وکارهای ایرانی است.
          از پشتیبانی مشتری تا تولید محتوا، همه‌چیز به فارسی.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12"
        >
          <motion.a
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            href="#"
            className="w-full sm:w-auto bg-gradient-to-r from-violet-600 to-cyan-600 text-white font-bold px-8 py-3 rounded-full shadow-lg shadow-violet-500/25"
          >
            همین الان شروع کن — رایگان
          </motion.a>
          <motion.a
            whileHover={{ scale: 1.05, borderColor: "#8b5cf6" }}
            href="#how-it-works"
            className="w-full sm:w-auto border border-white/30 text-white/80 font-medium px-8 py-3 rounded-full hover:bg-white/5 transition"
          >
            ببین چطور کار می‌کنه ←
          </motion.a>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="flex flex-col sm:flex-row items-center justify-center gap-6 text-sm text-white/60"
        >
          <motion.div variants={itemVariants} className="flex items-center gap-2">
            <div className="flex -space-x-2 space-x-reverse">
              {["bg-violet-400", "bg-amber-400", "bg-green-400", "bg-blue-400"].map((c, i) => (
                <div key={i} className={`w-8 h-8 rounded-full ${c} border-2 border-[#0a0a1a]`} />
              ))}
            </div>
            <span className="font-semibold">+۲,۰۰۰ کسب‌وکار فعال</span>
          </motion.div>
          <span className="hidden sm:block text-white/30">|</span>
          <motion.div variants={itemVariants} className="flex items-center gap-1">
            {[...Array(5)].map((_, i) => (
              <span key={i} className="text-amber-400 text-base">★</span>
            ))}
            <span className="mr-1 font-semibold">۴.۹ از ۵</span>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}