"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

const faqs = [
  { q: "آیا واقعاً فارسی رو درست می‌فهمه؟", a: "بله. مدل هوشمند روی میلیون‌ها متن فارسی آموزش دیده و زبان، اصطلاحات و فرهنگ ایرانی رو به خوبی درک می‌کنه." },
  { q: "داده‌های من کجا ذخیره می‌شه؟", a: "تمام داده‌ها روی سرورهای داخل ایران ذخیره می‌شن و هرگز از کشور خارج نمی‌شن." },
  { q: "آیا می‌تونم مدل رو با داده‌های خودم آموزش بدم؟", a: "در پلن حرفه‌ای می‌تونی مستندات، FAQها و اطلاعات محصولت رو آپلود کنی." },
  { q: "آیا API هم دارید؟", a: "بله. API کامل با مستندات فارسی و SDK برای Python، JavaScript و PHP داریم." },
  { q: "چطور می‌تونم پشتیبانی بگیرم؟", a: "پلن رایگان: پشتیبانی ایمیل. پلن حرفه‌ای: تیکت اولویت‌دار. پلن سازمانی: پشتیبان اختصاصی ۲۴/۷." },
  { q: "آیا دوره آزمایشی رایگان دارید؟", a: "بله! پلن حرفه‌ای ۱۴ روز رایگان بدون نیاز به کارت اعتباری امتحان کن." },
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section id="faq" className="py-24 bg-[#080818] relative">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml...')] opacity-5" />
      <div className="max-w-4xl mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-14"
        >
          <p className="text-indigo-400 text-xs font-bold mb-2 tracking-widest">سوالات متداول</p>
          <h2 className="text-4xl md:text-5xl font-black text-white">سوالی داری؟</h2>
          <p className="text-white/50 text-base mt-3">پاسخ اکثر سوالات رو اینجا پیدا می‌کنی.</p>
        </motion.div>

        <div className="space-y-4">
          {faqs.map((faq, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className={`rounded-2xl overflow-hidden transition-all ${
                openIndex === i
                  ? "bg-gradient-to-r from-violet-500/20 to-indigo-500/20 border border-violet-500/40"
                  : "bg-white/5 border border-white/10"
              }`}
            >
              <button
                className="w-full flex items-center justify-between gap-4 p-5 text-right hover:bg-white/5 transition"
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
              >
                <span className="text-white font-medium text-base">{faq.q}</span>
                <motion.span
                  animate={{ rotate: openIndex === i ? 45 : 0 }}
                  className="shrink-0 w-7 h-7 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-white/80 text-xl"
                >
                  +
                </motion.span>
              </button>
              <AnimatePresence>
                {openIndex === i && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <p className="px-5 pb-5 text-white/70 text-sm leading-relaxed">{faq.a}</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}