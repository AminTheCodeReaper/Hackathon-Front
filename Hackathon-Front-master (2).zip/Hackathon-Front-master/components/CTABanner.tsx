"use client";

import { motion } from "framer-motion";

export default function CTABanner() {
  return (
    <section className="py-20 relative">
      <div className="max-w-5xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="relative rounded-3xl bg-gradient-to-br from-violet-600/20 via-purple-600/10 to-cyan-600/20 backdrop-blur-xl border border-violet-500/30 p-10 md:p-14 text-center overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-64 h-64 bg-violet-500/20 rounded-full blur-3xl -z-10" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-cyan-500/20 rounded-full blur-3xl -z-10" />
          
          <motion.div
            animate={{ y: [0, -8, 0] }}
            transition={{ repeat: Infinity, duration: 2 }}
            className="text-6xl mb-5"
          >
            🚀
          </motion.div>
          <h2 className="text-4xl md:text-5xl font-black text-white mb-4">آماده‌ای رشد کنی؟</h2>
          <p className="text-white/60 text-base max-w-lg mx-auto mb-8 leading-relaxed">
            هزاران کسب‌وکار ایرانی الان از هوشمند استفاده می‌کنن.
            تو هم همین الان شروع کن — رایگان و بدون نیاز به کارت اعتباری.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-5">
            <motion.a
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              href="#"
              className="w-full sm:w-auto bg-gradient-to-r from-violet-600 to-cyan-600 text-white font-bold px-10 py-4 rounded-full shadow-lg shadow-violet-500/30"
            >
              همین الان شروع کن — رایگان
            </motion.a>
            <motion.a
              whileHover={{ x: 5 }}
              href="#"
              className="text-white/70 flex items-center gap-2 hover:text-white transition"
            >
              <span>با تیم فروش صحبت کن</span>
              <span>←</span>
            </motion.a>
          </div>

          <p className="text-white/30 text-xs mt-6">نیاز به کارت اعتباری نیست · ۱۴ روز آزمایشی رایگان · لغو آسان</p>
        </motion.div>
      </div>
    </section>
  );
}