"use client";

import { motion } from "framer-motion";

const footerLinks = {
  محصول: ["ویژگی‌ها", "قیمت‌گذاری", "مستندات API", "تغییرات جدید"],
  شرکت: ["درباره ما", "وبلاگ", "مشاغل", "تماس با ما"],
  پشتیبانی: ["مرکز راهنما", "جامعه کاربران", "وضعیت سرویس", "گزارش باگ"],
  حقوقی: ["حریم خصوصی", "شرایط استفاده", "سیاست کوکی"],
};

export default function Footer() {
  return (
    <footer className="bg-[#060612] border-t border-white/5 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-10 mb-14">
          <div className="col-span-2 md:col-span-1">
            <a href="#" className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-500 to-cyan-500 flex items-center justify-center text-white font-bold text-base">
                ه
              </div>
              <span className="text-white font-bold text-2xl">هوشمند</span>
            </a>
            <p className="text-white/40 text-sm leading-relaxed mb-4">
              اولین پلتفرم هوش مصنوعی بومی برای کسب‌وکارهای ایرانی.
            </p>
            <div className="flex gap-3">
              {["📷", "🐦", "💼", "📱"].map((icon, i) => (
                <motion.a
                  key={i}
                  whileHover={{ y: -3, scale: 1.1 }}
                  href="#"
                  className="w-9 h-9 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-base hover:bg-violet-500/20 transition"
                >
                  {icon}
                </motion.a>
              ))}
            </div>
          </div>

          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h4 className="text-white font-semibold text-sm mb-5">{category}</h4>
              <ul className="space-y-3">
                {links.map((link) => (
                  <li key={link}>
                    <a href="#" className="text-white/40 text-sm hover:text-white transition">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="border-t border-white/5 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-white/30 text-sm">
          <span>© ۱۴۰۴ هوشمند. تمام حقوق محفوظ است.</span>
          <span className="flex items-center gap-1">ساخته‌شده با ❤️ در ایران</span>
        </div>
      </div>
    </footer>
  );
}