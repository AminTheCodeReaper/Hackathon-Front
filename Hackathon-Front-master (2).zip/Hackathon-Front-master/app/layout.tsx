import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "هوشمند | تحول کسب‌وکار با هوش مصنوعی فارسی",
  description: "پلتفرم هوش مصنوعی بومی برای کسب‌وکارهای ایرانی – چت‌بات، تولید محتوا، تحلیل داده و پشتیبانی ۲۴/۷",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fa" dir="rtl" className="h-full scroll-smooth">
      <head>
        <link rel="preconnect" href="https://cdn.jsdelivr.net" />
      </head>
      <body className="min-h-full antialiased">{children}</body>
    </html>
  );
}