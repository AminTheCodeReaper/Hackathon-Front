"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";

const steps = [
  { step: "۱", title: "ثبت‌نام کن", description: "در کمتر از ۲ دقیقه حساب رایگانت رو بساز. نیاز به کارت اعتباری نیست.", icon: "👤" },
  { step: "۲", title: "ابزارت رو انتخاب کن", description: "از بین ده‌ها قالب آماده برای کسب‌وکارت انتخاب کن یا از صفر شروع کن.", icon: "🎯" },
  { step: "۳", title: "هوش مصنوعی رو آموزش بده", description: "داده‌های کسب‌وکارت رو آپلود کن. هوشمند یاد می‌گیره و شخصی‌سازی می‌شه.", icon: "🧠" },
  { step: "۴", title: "راه‌اندازی کن و رشد کن", description: "با یک کلیک منتشر کن. نتایج رو در داشبورد آنالیتیکس ببین.", icon: "🚀" },
];

export default function HowItWorks() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.3 });

  return (
    <section id="how-it-works" className="py-24 bg-gradient-to-b from-[#080818] to-[#0a0a1a] relative">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <p className="text-yellow-400 text-xs font-bold mb-2 uppercase tracking-widest">نحوه کار</p>
          <h2 className="text-4xl md:text-5xl font-black text-white">در ۴ گام شروع کن</h2>
          <p className="text-white/50 text-base mt-4 max-w-sm mx-auto">
            راه‌اندازی هوشمند ساده‌تر از آنی است که فکر می‌کنی.
          </p>
        </motion.div>

        <div ref={ref} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((s, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: i * 0.1, duration: 0.5 }}
              whileHover={{ y: -5 }}
              className="relative flex flex-col items-center text-center group"
            >
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-violet-500/20 to-cyan-500/20 border border-white/10 flex items-center justify-center text-3xl mb-5 group-hover:scale-110 transition duration-300 backdrop-blur-sm">
                {s.icon}
              </div>
              <span className="text-white/30 text-xs font-mono mb-1">مرحله {s.step}</span>
              <h3 className="text-white font-bold text-xl mb-2">{s.title}</h3>
              <p className="text-white/50 text-sm leading-relaxed max-w-xs">{s.description}</p>
              {i < steps.length - 1 && (
                <div className="hidden lg:block absolute top-10 left-[calc(100%-1rem)] w-8 h-0.5 bg-gradient-to-r from-violet-500/50 to-transparent" />
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}