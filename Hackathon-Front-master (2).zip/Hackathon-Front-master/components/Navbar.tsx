"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

const navLinks = [
  { label: "ویژگی‌ها", href: "#features" },
  { label: "نحوه کار", href: "#how-it-works" },
  { label: "قیمت‌گذاری", href: "#pricing" },
  { label: "سوالات", href: "#faq" },
];

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
      className={`fixed top-0 right-0 left-0 z-50 transition-all duration-300 ${
        scrolled ? "bg-[#0a0a1a]/80 backdrop-blur-xl border-b border-white/10" : "bg-transparent"
      } py-3`}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        <a href="#" className="flex items-center gap-2 group">
          <motion.div
            whileHover={{ rotate: 10, scale: 1.05 }}
            className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-500 to-cyan-500 flex items-center justify-center text-white font-bold text-lg shadow-lg"
          >
            ه
          </motion.div>
          <span className="text-white font-bold text-2xl tracking-tight">هوشمند</span>
        </a>

        <ul className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <motion.li key={link.href} whileHover={{ y: -2 }} transition={{ type: "spring", stiffness: 300 }}>
              <a href={link.href} className="text-white/70 hover:text-white text-sm font-medium transition">
                {link.label}
              </a>
            </motion.li>
          ))}
        </ul>

        <div className="hidden md:flex items-center gap-4">
          <a href="#" className="text-white/70 hover:text-white text-sm transition">ورود</a>
          <motion.a
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            href="#"
            className="bg-gradient-to-r from-violet-600 to-cyan-600 text-white text-sm font-semibold px-5 py-2 rounded-full shadow-lg"
          >
            شروع رایگان
          </motion.a>
        </div>

        <button className="md:hidden text-white/70" onClick={() => setMenuOpen(!menuOpen)}>
          <div className="w-6 flex flex-col gap-1.5">
            <span className="block h-0.5 bg-current rounded-full transition-all" />
            <span className="block h-0.5 bg-current rounded-full" />
            <span className="block h-0.5 bg-current rounded-full" />
          </div>
        </button>
      </div>

      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden bg-[#0f0f2a]/90 backdrop-blur-xl border-t border-white/10 px-6 py-5 flex flex-col gap-4"
          >
            {navLinks.map((link) => (
              <a key={link.href} href={link.href} className="text-white/80 text-base" onClick={() => setMenuOpen(false)}>
                {link.label}
              </a>
            ))}
            <a href="#" className="bg-violet-600 text-white font-semibold px-4 py-2 rounded-full text-center mt-2">
              شروع رایگان
            </a>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
}