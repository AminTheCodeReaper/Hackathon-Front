"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";

const plans = [
  {
    name: "رایگان",
    price: "۰",
    period: "همیشه رایگان",
    description: "برای شروع و آزمایش ایده‌ها",
    features: ["۱۰۰ درخواست در ماه", "چت‌بات پایه", "API دسترسی", "پشتیبانی ایمیل"],
    notIncluded: ["تحلیل داده", "یکپارچه‌سازی سفارشی"],
    cta: "شروع رایگان",
    highlighted: false,
    badge: null,
  },
  {
    name: "حرفه‌ای",
    price: "۴۹۰,۰۰۰",
    period: "تومان در ماه",
    description: "برای کسب‌وکارهای در حال رشد",
    features: ["۱۰,۰۰۰ درخواست در ماه", "چت‌بات پیشرفته", "تولید محتوا", "تحلیل داده پایه", "API کامل", "پشتیبانی اولویت‌دار"],
    notIncluded: ["یکپارچه‌سازی سفارشی"],
    cta: "۱۴ روز رایگان امتحان کن",
    highlighted: true,
    badge: "محبوب‌ترین",
  },
  {
    name: "سازمانی",
    price: "سفارشی",
    period: "با تیم ما صحبت کن",
    description: "برای کسب‌وکارهای بزرگ",
    features: ["درخواست‌های نامحدود", "همه ابزارها", "یکپارچه‌سازی سفارشی", "آموزش مدل اختصاصی", "SLA تضمین‌شده", "پشتیبانی ۲۴/۷ اختصاصی"],
    notIncluded: [],
    cta: "تماس با فروش",
    highlighted: false,
    badge: null,
  },
];

export default function Pricing() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  return (
    <section id="pricing" className="py-24 bg-gradient-to-b from-[#0a0a1a] to-[#050510]">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16 text-right md:text-center"
        >
          <div className="flex flex-wrap gap-3 items-center mb-4">
            <span className="text-yellow-400 text-xs font-bold tracking-widest border border-yellow-500/30 px-3 py-1 rounded-full">● قیمت‌گذاری</span>
            <span className="text-red-400 text-xs border border-red-400/30 px-2 py-0.5 rounded-full">تخفیف ویژه!</span>
            <span className="text-green-400 text-xs">✓ بدون هزینه پنهان</span>
          </div>
          <h2 className="text-5xl md:text-6xl font-black text-white leading-tight">شفاف،</h2>
          <h2 className="text-3xl font-light text-white/60">ساده، منصفانه</h2>
          <p className="text-white/50 text-sm mt-3 max-w-md mx-auto">پلنی مناسب هر مرحله از رشد کسب‌وکارت.</p>
        </motion.div>

        <div ref={ref} className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch">
          {plans.map((plan, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: idx * 0.1, duration: 0.5 }}
              whileHover={{ y: -8 }}
              className={`relative rounded-2xl p-8 backdrop-blur-sm transition-all duration-300 ${
                plan.highlighted
                  ? "bg-gradient-to-br from-violet-900/40 to-indigo-900/30 border-2 border-yellow-400/60 shadow-xl shadow-violet-500/20"
                  : "bg-white/5 border border-white/10"
              }`}
            >
              {plan.badge && (
                <div className="absolute -top-3 left-6 bg-yellow-400 text-black text-xs font-black px-4 py-1 rounded-full shadow-lg">
                  🔥 {plan.badge}
                </div>
              )}
              <div className="mb-4">
                <h3 className={`text-2xl font-black ${plan.highlighted ? "text-yellow-300" : "text-white"}`}>{plan.name}</h3>
                <p className="text-white/40 text-xs mt-1">{plan.description}</p>
              </div>
              <div className="mb-6 pb-4 border-b border-white/10">
                <span className={`text-4xl font-black ${plan.highlighted ? "text-white" : "text-white"}`}>
                  {plan.price === "سفارشی" ? plan.price : `${plan.price} تومان`}
                </span>
                <div className="text-white/30 text-xs mt-1">{plan.period}</div>
              </div>
              <ul className="space-y-3 mb-8">
                {plan.features.map((f, j) => (
                  <li key={j} className="flex items-center gap-2 text-white/80 text-sm">
                    <span className="text-emerald-400 text-base">✓</span> {f}
                  </li>
                ))}
                {plan.notIncluded.map((f, j) => (
                  <li key={j} className="flex items-center gap-2 text-white/30 line-through text-sm">
                    <span className="text-xs">✕</span> {f}
                  </li>
                ))}
              </ul>
              <motion.a
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                href="#"
                className={`block text-center py-3 rounded-full font-bold transition ${
                  plan.highlighted
                    ? "bg-yellow-400 text-black hover:bg-yellow-300"
                    : "bg-white/10 hover:bg-white/20 text-white border border-white/20"
                }`}
              >
                {plan.cta}
              </motion.a>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mt-10 flex flex-wrap justify-center gap-x-6 gap-y-2 text-xs text-white/30 border-t border-white/5 pt-6 text-center"
        >
          <span>✓ لغو هر زمان</span>
          <span>✓ بدون قرارداد</span>
          <span className="text-green-400/60">✓ ۱۴ روز ضمانت بازگشت وجه</span>
          <span>پشتیبانی: support@hooshmand.ai</span>
        </motion.div>
      </div>
    </section>
  );
}