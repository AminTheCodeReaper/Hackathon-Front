"use client";

import { motion, useInView } from "framer-motion";
import { useRef, useState, useEffect } from "react";

const stats = [
  { value: "۲۰۰۰+", label: "کسب‌وکار فعال", sublabel: "در سراسر ایران", numeric: 2000 },
  { value: "۱۲M+", label: "مکالمه پردازش‌شده", sublabel: "ماهانه", numeric: 12 },
  { value: "۹۸٪", label: "رضایت مشتریان", sublabel: "براساس نظرسنجی", numeric: 98 },
  { value: "۳۰ ثانیه", label: "میانگین پاسخ", sublabel: "به سوالات مشتریان", numeric: 30 },
];

const CountUp = ({ value, suffix = "" }: { value: number; suffix?: string }) => {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  useEffect(() => {
    if (isInView) {
      let start = 0;
      const end = value;
      const duration = 1500;
      const increment = end / (duration / 16);
      const timer = setInterval(() => {
        start += increment;
        if (start >= end) {
          setCount(end);
          clearInterval(timer);
        } else {
          setCount(Math.floor(start));
        }
      }, 16);
      return () => clearInterval(timer);
    }
  }, [isInView, value]);

  return <span ref={ref}>{count}{suffix}</span>;
};

export default function Stats() {
  const containerRef = useRef(null);
  const isInView = useInView(containerRef, { once: true, amount: 0.3 });

  return (
    <section className="py-20 border-y border-white/5 bg-black/20">
      <div className="max-w-7xl mx-auto px-6">
        <div ref={containerRef} className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((s, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ delay: i * 0.1, duration: 0.4 }}
              className="text-center bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/5 hover:border-violet-500/30 transition"
            >
              <div className="text-3xl md:text-5xl font-black bg-gradient-to-r from-violet-400 to-cyan-400 bg-clip-text text-transparent mb-2">
                {s.value.includes("M+") ? (
                  <><CountUp value={s.numeric} />M+</>
                ) : s.value.includes("٪") ? (
                  <><CountUp value={s.numeric} />%</>
                ) : s.value.includes("ثانیه") ? (
                  <><CountUp value={s.numeric} /> ثانیه</>
                ) : (
                  <><CountUp value={s.numeric} />+</>
                )}
              </div>
              <div className="text-white/90 text-base font-semibold">{s.label}</div>
              <div className="text-white/40 text-xs mt-1">{s.sublabel}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}