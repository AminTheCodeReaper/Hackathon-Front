"use client";

import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";

const features = [
  { icon: "💬", title: "چت‌بات هوشمند فارسی", description: "دستیار مکالمه‌ای که زبان، فرهنگ و نیازهای کاربر ایرانی را کاملاً درک می‌کند.", color: "from-pink-500/20 to-pink-600/5" },
  { icon: "✍️", title: "تولید محتوای خودکار", description: "از توضیحات محصول تا پست‌های شبکه اجتماعی — همه را در چند ثانیه بنویس.", color: "from-yellow-500/20 to-yellow-600/5" },
  { icon: "📊", title: "تحلیل داده پیشرفته", description: "بینش‌های ارزشمند از داده‌های کسب‌وکارت استخراج کن بدون نیاز به متخصص داده.", color: "from-blue-500/20 to-blue-600/5" },
  { icon: "🎧", title: "پشتیبانی ۲۴/۷", description: "به مشتریانت شبانه‌روز پاسخ بده. بدون خستگی، بدون اشتباه، با لحن برند خودت.", color: "from-green-500/20 to-green-600/5" },
  { icon: "🔗", title: "یکپارچه‌سازی آسان", description: "با یک API ساده به هر سیستمی وصل شو. SDK فارسی با مستندات کامل.", color: "from-orange-500/20 to-orange-600/5" },
  { icon: "🔒", title: "امنیت و حریم خصوصی", description: "داده‌هایت روی سرورهای داخل ایران ذخیره می‌شه. کاملاً امن و مطابق قوانین.", color: "from-red-500/20 to-red-600/5" },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
};

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
};

export default function Features() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  return (
    <section id="features" className="py-24 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-14"
        >
          <p className="text-green-400 text-xs font-bold mb-2 tracking-widest">— ویژگی‌ها —</p>
          <h2 className="text-4xl md:text-5xl font-black text-white">همه چیزی که نیاز داری</h2>
          <p className="text-white/50 text-base mt-3 max-w-lg">
            ابزارهای قدرتمند هوش مصنوعی که به‌طور خاص برای بازار ایران طراحی شده‌اند.
          </p>
        </motion.div>

        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {features.map((f, i) => (
            <motion.div
              key={i}
              variants={itemVariants}
              whileHover={{ y: -8, scale: 1.02 }}
              className={`relative group rounded-2xl p-6 backdrop-blur-sm border border-white/10 bg-gradient-to-br ${f.color} hover:border-violet-500/50 transition-all duration-300`}
            >
              <div className="text-4xl mb-4">{f.icon}</div>
              <h3 className="text-white font-bold text-xl mb-2">{f.title}</h3>
              <p className="text-white/60 text-sm leading-relaxed">{f.description}</p>
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-violet-500/0 to-cyan-500/0 group-hover:from-violet-500/5 group-hover:to-cyan-500/5 transition duration-300" />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}