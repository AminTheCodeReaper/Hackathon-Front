"use client";

import { motion } from "framer-motion";

const brands = [
  "دیجی‌کالا", "اسنپ", "تپسی", "شیپور", "دیوار", "فیلیمو", "آپارات", "باشگاه مشتریان"
];

export default function BrandsStrip() {
  return (
    <section className="py-12 bg-white/2 border-y border-white/5 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <motion.p
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="text-right text-cyan-400 text-xs font-bold mb-6 tracking-wider"
        >
          ★ مورد اعتماد بهترین کسب‌وکارهای ایران ★
        </motion.p>

        <div className="relative flex overflow-hidden">
          <motion.div
            animate={{ x: ["0%", "-50%"] }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            className="flex gap-5 flex-nowrap whitespace-nowrap"
          >
            {[...brands, ...brands].map((brand, i) => (
              <div
                key={i}
                className="flex items-center gap-2 text-white/50 border border-white/10 px-5 py-2 rounded-full bg-white/5 backdrop-blur-sm hover:bg-white/10 transition"
              >
                <div className="w-7 h-7 rounded-full bg-gradient-to-br from-violet-500 to-cyan-500 flex items-center justify-center text-xs text-white font-bold">
                  {brand[0]}
                </div>
                <span className="text-sm font-medium">{brand}</span>
              </div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}